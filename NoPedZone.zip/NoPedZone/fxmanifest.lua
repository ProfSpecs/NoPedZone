fx_version 'cerulean'
game 'gta5'

author 'Specs'
description 'NoPedZone - Prevents ped and vehicle spawns in custom polyzones. Configurable, lightweight, and easy to use.'
version '1.0.0'

client_script 'client.lua'
shared_script 'config.lua'